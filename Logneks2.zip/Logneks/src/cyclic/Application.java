package cyclic;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import cyclic.Dependents;

public class Application {
	private Dependents deps;
	
	public static void main(String[] args) {
		Application application = new Application();
        application.init();
        application.run();
	}
	
	public void init() {
		ArrayList<String> depsList = new ArrayList<String>();
		/*
		try(BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in))){
        	String strIn;
            while((strIn=stdin.readLine())!=null){
            	depsList.add(strIn);
            }
        } catch (IOException e) {
            System.out.println("Reading error");
        }
        */
		depsList.add("1 2");
		depsList.add("2 1");
		depsList.add("3 4");
		depsList.add("5 6");
		depsList.add("6 5");
		depsList.add("1 2");
		depsList.add("2 1");
		depsList.add("3 4");
		depsList.add("5 6");
		depsList.add("6 5");


		System.out.println("Source file:");
		for(String line: depsList){
	        System.out.println(line);
		}
		System.out.println("Cyclic:");
		
        deps = new Dependents(depsList);
	}
	
    public void run() {
    	try(BufferedWriter stdout = new BufferedWriter(new OutputStreamWriter(System.out))){
    		for(String strOut: deps.getCyclic()){
        		stdout.write(strOut+System.getProperty("line.separator"));
        	}
    	} catch (IOException e) {
            System.out.println("Writing error");
        }
    }
}

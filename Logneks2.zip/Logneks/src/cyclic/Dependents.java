package cyclic;

import java.util.ArrayList;

public class Dependents {
	private ArrayList<Integer> col1 = new ArrayList<Integer>();
	private ArrayList<Integer> col2 = new ArrayList<Integer>();
	private ArrayList<String> cyclicDepsList;
	
	public Dependents(ArrayList<String> depsList) {
		for(int i=0; i<depsList.size(); i++) {
			col1.add(Integer.parseInt(depsList.get(i).split(" ")[0]));
			col2.add(Integer.parseInt(depsList.get(i).split(" ")[1]));
		}
	}
	
	public ArrayList<String> getCyclic() {
		cyclicDepsList = new ArrayList<String>();
		String newCyclicDep;
		
		for(int i=0; i<(col1.size()-1); i++) {
			for(int j=(i+1); j<col1.size(); j++) {
				if(col1.get(i)==(col2.get(j)) && col2.get(i)==(col1.get(j))) {
					newCyclicDep = col1.get(i)+" "+col2.get(i)+" "+col1.get(i);
					
					if(!this.hasCyclicDepSynonym(newCyclicDep)){
						cyclicDepsList.add(newCyclicDep);
					}
				}
			}
		}

		return cyclicDepsList;
	}
	
	private Boolean hasCyclicDepSynonym(String dep){
		for(String line: cyclicDepsList){
			if(line.contains(dep.split(" ")[0]) && 
					line.contains(dep.split(" ")[1])) {
				return true;
			}
		}
		
		return false;
	}
}
